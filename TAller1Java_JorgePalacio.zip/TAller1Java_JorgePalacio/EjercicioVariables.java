public class EjercicioVariables {
    public static void main(String[] args) {

        //Variable para almacenar el nombre
        String nombre = "Jorge";
        //Variable para almacenar un número con dos decimales
        double numero = 0.55;
        //Variable constante para almcaenar el valor del dolar
        final double dolar = 4201.41;
        //Variable primitiva para almacenar los primeros 7 decimales de “pi”
        double pi = 3.1415926;
        //Variable de estructura para almacenar los primeros 15 decimales de “Euler”.
        double euler = 	2.718281828459045;
        
        System.out.println(nombre);
        System.out.println(numero);
        System.out.println(dolar);
        System.out.println(pi);
        System.out.println(euler);

    }  
}